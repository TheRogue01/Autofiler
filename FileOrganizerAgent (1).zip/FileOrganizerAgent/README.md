# Smart Autonomous File Organization and Monitoring Agent

An intelligent, agent-based file management system for Operating Systems coursework.

---

## Features

| Feature | Description |
|---|---|
| **File Sorting** | Automatically classifies files into Images, Documents, Videos, Music, Archives, Code, Executables, Others |
| **Smart Categorisation** | Keyword-based sub-folders inside Documents (Work, Study, Finance, Personal) |
| **Real-time Monitoring** | Watchdog-powered live folder watcher — organises files the instant they appear |
| **Duplicate Detection** | MD5 hash comparison; duplicates go to a separate Duplicates folder |
| **Large File Detection** | Configurable threshold (default 500 MB); large files routed to LargeFiles/ |
| **Undo System** | JSON-backed history; undo the last move or restore everything at once |
| **Logging** | Every action timestamped to `logs/organizer_YYYYMMDD.log` |
| **Dark-mode GUI** | Clean tkinter interface — no extra dependencies beyond `watchdog` |
| **Empty Folder Cleanup** | One-click removal of leftover empty directories |

---

## Project Structure

```
FileOrganizerAgent/
├── main.py          ← GUI entry-point (run this)
├── organizer.py     ← Core classification, moving & undo logic
├── monitor.py       ← Real-time watchdog / polling monitor
├── utils.py         ← Logging, hashing, size helpers
├── requirements.txt
├── logs/            ← Auto-created log files
└── organized/       ← Default destination root
```

---

## Setup

```bash
# 1. Install the only external dependency
pip install -r requirements.txt

# 2. Launch the GUI
python main.py
```

> Python 3.10+ required (uses the `match`-free union type hint `X | Y`).  
> If you are on Python 3.9 change `str | None` → `Optional[str]` in organizer.py / monitor.py.

---

## How to Use

1. **Select Source Folder** — the messy folder to clean up (default: Downloads).  
2. **Select Destination Root** — where category sub-folders will be created.  
3. **Organise Now** — one-shot scan and sort.  
4. **Start Monitor** — background watcher; every new file is sorted instantly.  
5. **Undo Last / Undo All** — restore files to their original locations.  
6. **Remove Empty Folders** — tidy up leftover directories in the source.

---

## Organised Folder Layout

```
organized/
├── Images/
├── Documents/
│   ├── Work/
│   ├── Study/
│   ├── Finance/
│   └── Personal/
├── Videos/
├── Music/
├── Archives/
├── Code/
├── Executables/
├── LargeFiles/
├── Duplicates/
└── Others/
```

---

## What Makes It "Agentic"

The system:
- **Observes** the environment (watchdog events / polling)
- **Decides** where each file belongs (classification + smart rules)
- **Acts** autonomously (moves files, creates folders, logs actions)
- **Adapts** (duplicate handling, large-file routing, undo)

---

## Presentation Demo Script

1. Open the GUI and point it at a messy test folder.  
2. Click **Organise Now** — watch the log fill with moves.  
3. Drop a new file into the folder while monitoring is active — it sorts itself.  
4. Drop a duplicate — it goes straight to Duplicates/.  
5. Click **Undo Last** — the file returns home.  
6. Show the generated log file in `logs/`.
